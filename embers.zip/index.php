<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/css.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/bootstrap-material-design.min.css">
 <title>Emberlabs Softwares</title>
  </head>
  <body>

<div class="container text-center" style="padding-top:145px">
<img src="images/flask.png" width="150rem" class="animate__animated animate__wobble animate__infinite">
<br>
<br>
<h3 class="text-danger">The site is under-construction.</h3>
<a class="btn btn-raised btn-warning" href="https://www.facebook.com/emberlabs">Social Media Page</a>
</div>

<footer class="text-center">
<img src="images/cover.jpg" width="200rem" class="" style="padding-top:160px">
</footer>



</footer>
    <script src="js/jquery-3.2.1.slim.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap-material-design.js"></script>
    <script>$(document).ready(function() { $('body').bootstrapMaterialDesign(); });</script>
  </body>
</html>